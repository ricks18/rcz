const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Shurek:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}o*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *Henrique*
  DUVIDAS? 👇
  Chama o Cesar
╚════════════════════`
}

exports.darkmenu = darkmenu








