const help = (p, date, user, wame) => {
return `┏━🔥࿗ 𝐒𝐇𝐔𝐑𝐄𝐊 𝐁𝐎𝐓 ࿗🔥━┓
║                                                           
║ _*🕐 𝐃𝐚𝐭𝐚 𝐞 𝐡𝐨𝐫𝐚: ${date} 🕐*_
║ _*🙂 𝐔𝐬𝐮𝐚́𝐫𝐢𝐨: ${user} 🙂*_
║ _*🌎 𝐖𝐚𝐦𝐞: ${wame} 🌎*_                                        
║                                                           
┣══════𝑨𝒃𝒂𝒊𝒙𝒐 𝒐𝒔 𝒄𝒐𝒎𝒂𝒏𝒅𝒐𝒔══════┫

★彡 ༻⚡𝙿𝚛𝚒𝚗𝚌𝚒𝚙𝚊𝚒𝚜⚡༺ 彡★
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}listblockcmd*
❁❧ *${p}listpalavra*
❁❧ *${p}info*
❁❧ *${p}ping*
❁❧ *${p}destrava*
❁❧ *${p}sugerircmd* ❮text❯
❁❧ *${p}terbot*
❁❧ *${p}botvip*
❁❧ *${p}blocklist*
❁❧ *${p}blacklist*
❁❧ *${p}criador*
❁❧ *${p}toimg* ❮caption, reply img❯


ıllıllı ༻✨ 𝚂𝚝𝚒𝚌𝚔𝚎𝚛𝚜 ✨༺ ıllıllı
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}stiker* ❮caption, reply img❯
❁❧ *${p}sticker* ❮caption, reply img❯
❁❧ *${p}fstiker* ❮caption, reply img❯
❁❧ *${p}fsticker* ❮caption, reply img❯
❁❧ *${p}attp* ❮txt❯
❁❧ *${p}macaco*

♨♨ ༻💀 𝚛𝚘𝚕𝚎𝚝𝚊 𝚛𝚞𝚜𝚜𝚊 💀༺ ♨♨
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}roletarussahard*
❁❧ *${p}roletarussamed*
❁❧ *${p}roletarussaeasy*
❁❧ *${p}roletarussapac*


☆.｡.:* ༻🎥 𝚅𝚒́𝚍𝚎𝚘 🎥༺ *:.｡.☆
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}frame* ❮sec❯ ❮reply video❯
❁❧ *${p}mute* ❮reply video❯
❁❧ *${p}rapidovid* ❮reply video❯
❁❧ *${p}lentovid* ❮reply video❯
❁❧ *${p}togif* ❮reply video❯
❁❧ *${p}resizevid* ❮lag❯ ❮alt❯ ❮reply vid❯


:.｡○ ༻📷 𝚎𝚍𝚒𝚝𝚘𝚛 𝚍𝚎 𝚏𝚘𝚝𝚘𝚜 📷༺ ○｡.:
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}cropimg* ❮lag❯ ❮alt❯ ❮reply img❯
❁❧ *${p}bwimg* ❮reply img❯
❁❧ *${p}identifyimg* ❮reply img❯
❁❧ *${p}monochromeimg* ❮reply img❯
❁❧ *${p}resizeimg* ❮lag❯ ❮alt❯ ❮reply img❯
❁❧ *${p}blurimg* ❮rad❯ ❮sig❯ ❮reply img❯
❁❧ *${p}flowerlogo* ❮txt❯
❁❧ *${p}matrixlogo* ❮txt❯
❁❧ *${p}thunderlogo* ❮txt❯
❁❧ *${p}silverplaca* ❮txt❯
❁❧ *${p}goldplaca* ❮txt❯
❁❧ *${p}narutologo* ❮txt❯
❁❧ *${p}phlogo* ❮t1❯ | ❮t2❯
❁❧ *${p}mineconquista* ❮t1❯ | ❮t2❯
❁❧ *${p}shadow* ❮txt❯
❁❧ *${p}glitch* ❮t1❯ | ❮t2❯
❁❧ *${p}ravetxt* ❮t1❯ | ❮t2❯
❁❧ *${p}woodtxt* ❮t1❯ | ❮t2❯
❁❧ *${p}neon* ❮t1❯ | ❮t2❯
❁❧ *${p}sunset* ❮t1❯ | ❮t2❯
❁❧ *${p}gimage* ❮txt❯
❁❧ *${p}pglass* ❮txt❯
❁❧ *${p}neonligth* ❮txt❯
❁❧ *${p}coffe* ❮txt❯
❁❧ *${p}galaxywp* ❮txt❯
❁❧ *${p}whatis* ❮txt❯
❁❧ *${p}txt3d* ❮txt❯

⚆ _ ⚆ ༻🔍 𝙿𝚎𝚜𝚚𝚞𝚒𝚜𝚊 🔎 ༺ ⚆ _ ⚆
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}mob*
❁❧ *${p}minecraft*
❁❧ *${p}infocovid*
❁❧ *${p}covidmundo*
❁❧ *${p}foxnews*
❁❧ *${p}lofi*
❁❧ *${p}boy*
❁❧ *${p}girl*
❁❧ *${p}egirl*
❁❧ *${p}eboy*
❁❧ *${p}pinterest* ❮name❯
❁❧ *${p}wallpaper*
❁❧ *${p}fuckmylife*
❁❧ *${p}waifu*
❁❧ *${p}belle*
❁❧ *${p}saycat*
❁❧ *${p}biblia*
❁❧ *${p}animesrc* ❮name anime❯
❁❧ *${p}mangasrc* ❮name anime❯
❁❧ *${p}playstore* ❮name app❯
❁❧ *${p}happymod* ❮name app❯
❁❧ *${p}pokemon*
❁❧ *${p}ip* ❮ip❯
❁❧ *${p}signome* ❮name❯
❁❧ *${p}gimage* ❮name❯


•.¸♡ ༻😈 𝙿𝚘𝚛𝚗𝚘😈༺ ♡¸.•
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}packmega18*
❁❧ *${p}checkporn* ❮reply img❯
❁❧ *${p}nhentai* ❮code❯
❁❧ *${p}randomhentai*
❁❧ *${p}nsfwblowjob*
❁❧ *${p}nsfwneko*
❁❧ *${p}nsfwtrap*
❁❧ *${p}nsfw* ❮1 or 0❯


☆.｡.:* ༻🗣️ 𝚟𝚘𝚣 𝚖𝚘𝚍 🗣️༺ *:.｡.☆
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}esquilo* ❮reply audio❯
❁❧ *${p}grave* ❮reply audio❯
❁❧ *${p}estourar* ❮reply audio❯
❁❧ *${p}rapidoaudio* ❮reply audio❯
❁❧ *${p}lentoaudio* ❮reply audio❯
❁❧ *${p}bass* ❮reply audio❯


.•♫•♬• ༻🎵 𝙰𝚞𝚍𝚒𝚘 🎵༺ •♫•♬•
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}gtts* ❮la❯ ❮txt❯
❁❧ *${p}playlist*
❁❧ *${p}lyrics*
❁❧ *${p}ptlyrics*
❁❧ *${p}play* ❮music name❯
❁❧ *${p}playv2* ❮music name❯
❁❧ *${p}tomp3* ❮caption, reply video❯
❁❧ *${p}ytsearch* ❮name❯
❁❧ *${p}ytmp4* ❮yt url❯
❁❧ *${p}ytmp3* ❮yt url❯


✧･ﾟ: ✧･ﾟ:⚙️ Gerador ⚙️:･ﾟ✧:･ﾟ✧
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}gpessoa*
❁❧ *${p}gendereco*
❁❧ *${p}gcnh*
❁❧ *${p}geleitortitulo*
❁❧ *${p}gbanco*
❁❧ *${p}gcarro*
❁❧ *${p}gpass* ❮letter qnt❯
❁❧ *${p}cpf*
❁❧ *${p}ddd* ❮ddd❯
❁❧ *${p}cep* ❮cep❯
❁❧ *${p}gerarcc*
❁❧ *${p}gprocesso*
❁❧ *${p}gerarcc*
❁❧ *${p}gcarro*


▀▄▀▄▀▄ ༻🧾 𝚃𝚎𝚡𝚝𝚘 🧾༺ ▄▀▄▀▄▀
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}fakeidentity*
❁❧ *${p}txtcmd*
❁❧ *${p}installbot*
❁❧ *${p}traduz* ❮la❯ ❮txt❯
❁❧ *${p}wame*
❁❧ *${p}repeat* ❮txt❯
❁❧ *${p}ocr* ❮caption, reply video❯
❁❧ *${p}nethunter*
❁❧ *${p}idioma*
❁❧ *${p}frase*
❁❧ *${p}wppim*
❁❧ *${p}db*


✦✧✧ ༻🇯🇵 𝙰𝚗𝚒𝚖𝚎𝚜 🇯🇵༺ ✧✧✦
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}randomanime*
❁❧ *${p}randomshota*
❁❧ *${p}randomkiss*
❁❧ *${p}randomcry*
❁❧ *${p}randomhug*
❁❧ *${p}nekoanime*
❁❧ *${p}wait* ❮caption, reply video❯


••¤(×[¤ ༻👾 𝙲𝚘𝚍𝚒𝚐𝚘𝚜 👾༺ ¤]×)¤••
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}txtomorse* ❮txt❯
❁❧ *${p}morsetotxt* ❮txt❯
❁❧ *${p}ebinary* ❮txt❯
❁❧ *${p}dbinary* ❮txt❯


☆.｡.:* ༻🏆 𝚛𝚊𝚗𝚔𝚒𝚗𝚐𝚜 🏆༺ *:.｡.☆
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}ranklindo*
❁❧ *${p}rankfeio*
❁❧ *${p}rankgado*
❁❧ *${p}rankcomu*
❁❧ *${p}ranknazi*
❁❧ *${p}rankqi*
❁❧ *${p}rankfofo*
❁❧ *${p}rankotaku*
❁❧ *${p}rankgay*


✧･ﾟ: ༻🔮 𝙿𝚛𝚎𝚟𝚒𝚜𝚘̃𝚎𝚜 🔮༺ :･ﾟ✧
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}cassino*
❁❧ *${p}ship* ❮num1❯ ❮num2❯
❁❧ *${p}corno* ❮num1❯
❁❧ *${p}nazista* ❮num1❯
❁❧ *${p}comunista* ❮num1❯
❁❧ *${p}dado*
❁❧ *${p}gay* ❮num1❯
❁❧ *${p}qi* ❮num1❯
❁❧ *${p}seudia* ❮num1❯
❁❧ *${p}feio* ❮num1❯
❁❧ *${p}bv* ❮num1❯
❁❧ *${p}gado* ❮num1❯
❁❧ *${p}gostoso* ❮num1❯
❁❧ *${p}gostosa* ❮num1❯
❁❧ *${p}randomship* ❮num1 or n/a❯


•¯•. ༻📱 𝚀𝚛 𝚌𝚘𝚍𝚎 📱༺ .•¯•
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}qrcode* ❮txt❯
❁❧ *${p}qrcodebg* ❮txt❯
❁❧ *${p}qrcodegb* ❮txt❯
❁❧ *${p}qrcodebb* ❮txt❯
❁❧ *${p}qrcodebb1* ❮txt❯
❁❧ *${p}qrcoderb* ❮txt❯
❁❧ *${p}qrcodebr* ❮txt❯

• ••´º´•» ༻❌ 𝙰𝚗𝚝𝚒𝚜 ❌༺ «•´º´•• •
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}antidoc* ❮1 or 0❯
❁❧ *${p}antiloc* ❮1 or 0❯
❁❧ *${p}antiimg* ❮1 or 0❯
❁❧ *${p}antipalavra* ❮1 or 0❯
❁❧ *${p}antivideo* ❮1 or 0❯
❁❧ *${p}antisticker* ❮1 or 0❯
❁❧ *${p}antiaudio* ❮1 or 0❯
❁❧ *${p}antictt* ❮1 or 0❯
❁❧ *${p}antilink* ❮1 or 0❯
❁❧ *${p}antiporn* ❮1 or 0❯
❁❧ *${p}antifake* ❮1 or 0❯
❁❧ *${p}antilinkhard* ❮1 or 0❯


╚»★«╝ ༻👥 𝙶𝚛𝚞𝚙𝚘𝚜 👥༺ ╚»★«╝
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}fechargp*
❁❧ *${p}mudardesc*
❁❧ *${p}mudarnome*
❁❧ *${p}abrirgp*
❁❧ *${p}linkgroup*
❁❧ *${p}listadmin*
❁❧ *${p}listonline*
❁❧ *${p}leave*
❁❧ *${p}kick* ❮dial num❯
❁❧ *${p}ban* ❮reply message❯
❁❧ *${p}promote* ❮dial num❯
❁❧ *${p}demote* ❮dial num❯
❁❧ *${p}add* ❮num❯
❁❧ *${p}roletrussablock* ❮1 or 0❯
❁❧ *${p}welcome* ❮1 or 0❯
❁❧ *${p}simih* ❮1 or 0❯
❁❧ *${p}autostickerimg* ❮1 or 0❯
❁❧ *${p}onmodgrupo*
❁❧ *${p}offmodgrupo*
❁❧ *${p}autoreply* ❮1 or 0❯
❁❧ *${p}marcar*
❁❧ *${p}marcar2*
❁❧ *${p}marcar3*
❁❧ *${p}hidemarcar* ❮txt❯


┈━═☆ ༻🕵️ 𝚂𝚝𝚊𝚕𝚔𝚎𝚛 🕵️༺ ☆═━┈
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}instastalk* <name>
❁❧ *${p}githubstalk* <name>
❁❧ *${p}tiktokstalk* <name>


(--) ༻😳 𝙸𝚗𝚝𝚎𝚛𝚊𝚌̧𝚊̃𝚘 😳༺ (--)
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}vsf*
❁❧ *${p}botfofo*
❁❧ *${p}pedro*
❁❧ *${p}botgostoso*
❁❧ *${p}botviado*
❁❧ *${p}botbaianor*
❁❧ *${p}botfdp*
❁❧ *${p}botfeio*
❁❧ *${p}botputa*
❁❧ *${p}botgay*
❁❧ *${p}botcorno*
❁❧ *${p}vtmnc*
❁❧ *${p}bomdia*
❁❧ *${p}boatarde*
❁❧ *${p}boanoite*
❁❧ *${p}lindo*
❁❧ *${p}cheguei*


:..｡o○ ༻😎 𝙲𝚛𝚒𝚊𝚍𝚘𝚛 😎༺ ○o｡..:
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}blockcmd* ❮cmd less prefix❯
❁❧ *${p}unblockcmd* ❮cmd less prefix❯
❁❧ *${p}alerta* ❮txt❯
❁❧ *${p}addpalavra* ❮txt❯
❁❧ *${p}removepalavra* ❮txt❯
❁❧ *${p}limparchat* ❮txt❯
❁❧ *${p}ataque* ❮txt❯
❁❧ *${p}divulgar* ❮txt❯
❁❧ *${p}entrargp* ❮txt❯
❁❧ *${p}block* ❮num❯
❁❧ *${p}unblock* ❮num❯


(ᵔᴥᵔ) ༻😝 𝙳𝚒𝚟𝚎𝚛𝚜𝚊̃𝚘 😝༺ (ᵔᴥᵔ)
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}meme*
❁❧ *${p}memeindo*
❁❧ *${p}darkjokes*


▃▅▆█ 웃 ༻💱 𝙼𝚘𝚎𝚍𝚊 💱༺ 웃 █▆▅▃
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡

❁❧ *${p}dolarhoje*
❁❧ *${p}rublohoje*
❁❧ *${p}ienehoje*
❁❧ *${p}librahoje*
❁❧ *${p}bitcoinhoje*
❁❧ *${p}realhoje*
❁❧ *${p}cvoin* ❮c1❯|❮c2❯
❁❧ *${p}ccoin* ❮c1❯|❮c2❯|❮num❯`
}

exports.help = help


