const help = (p, date, user, wame) => {
return `┏═
║╔══✪〘 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂𝐎𝐄𝐒〙✪══
║
╠ *🤖𝑺𝑯𝑼𝑹𝑬𝑲 𝑩𝑶𝑻🤖* 
╠🤖 VERSÃO: *3.0*
╠🤖 𝐃𝐎𝐍𝐎: 𝗵𝗲𝗻𝗿𝗶𝗾𝘂𝗲 
╠🤖 ${user}
╠🤖  *BASE:* BRIZAS
║
╠══✪〘 𝐏𝐑𝐈𝐍𝐂𝐈𝐏𝐀𝐈𝐒 〙✪══
║
║📌 *!listblockcmd*
║⚜️ *!listpalavra*
║⚜️ *!info*
║📌 *!ping*
║⚜️ *!destrava*
║⚜️ *!sugerircmd* [text]
║⚜️ *!blocklist
║📌 *!blacklist*
║📌 *!toimg* [marcar img]
║
╠══✪〘 𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀 〙✪══
║
║📌 *!stiker* [legenda, marcar img]
║📌 *!sticker* [legenda, marcar img]
║📌 *!fstiker* [legenda, marcar img]
║📌 *!attp* [texto]
║📌 *!macaco*
║
╠══✪〘 𝐑𝐎𝐋𝐄𝐓𝐀 〙✪══
║
║📌 *!roletarussahard*
║📌 *!roletarussamed*
║📌 *!roletarussaeasy*
║📌 *!roletarussapac*
║
║
╠══✪〘 𝐕𝐈𝐃𝐄𝐎 〙✪══
║
║📌 *!frame* [sec] [marcar vid]
║📌 *!mute* [marcr video]
║📌 *!rapidovid* [marcar vid]
║📌 *!togif* [marcar vid]
║📌 *!resizevid* [larg, alt]
║
╠══✪〘 𝐈𝐌𝐀𝐆𝐄𝐍𝐒 〙✪══
║
║ *!cropimg* ❮lag❯ ❮alt❯ ❮reply img❯
║ *!bwimg* ❮reply img❯
║ *!identifyimg* ❮reply img❯
║ *!monochromeimg* ❮reply img❯
║ *!resizeimg* ❮lag❯ ❮alt❯ ❮reply img❯
║ *!blurimg* ❮rad❯ ❮sig❯ ❮reply img❯
║ *!flowerlogo* ❮txt❯
║ *!matrixlogo* ❮txt❯
║ *!thunderlogo* ❮txt❯
║ *!silverplaca* ❮txt❯
║ *!goldplaca* ❮txt❯
║ *!narutologo* ❮txt❯
║ *!phlogo* ❮t1❯ | ❮t2❯
║ *!mineconquista* ❮t1❯ | ❮t2❯
║ *!shadow* ❮txt❯
║ *!glitch* ❮t1❯ | ❮t2❯
║ *!ravetxt* ❮t1❯ | ❮t2❯
║ *!woodtxt* ❮t1❯ | ❮t2❯
║ *!neon* ❮t1❯ | ❮t2❯
║ *!sunset* ❮t1❯ | ❮t2❯
║ *!gimage* ❮txt❯
║ *!pglass* ❮txt❯
║ *!neonligth* ❮txt❯
║ *!coffe* ❮txt❯
║ *!galaxywp* ❮txt❯
║ *!whatis* ❮txt❯
║ *!txt3d* ❮txt❯
║
╠══✪〘 𝐏𝐄𝐒𝐐𝐔𝐈𝐒𝐀 〙✪══
║
║ *!mob*
║ *!minecraft*
║ *!infocovid*
║ *!covidmundo*
║ *!foxnews*
║ *!lofi*
║ *!boy*
║ *!girl*
║ *!egirl*
║ *!eboy*
║ *!pinterest* ❮name❯
║ *!wallpaper*
║ *!fuckmylife*
║ *!waifu*
║ *!belle*
║ *!saycat*
║ *!biblia*
║ *!animesrc* ❮name anime❯
║ *!mangasrc* ❮name anime❯
║ *!playstore* ❮name app❯
║ *!happymod* ❮name app❯
║ *!pokemon*
║ *!ip* ❮ip❯
║ *!signome* ❮name❯
║ *!gimage* ❮name❯
║
╠══✪〘 𝐏𝐎𝐑𝐍𝐎 〙✪══
║
║ *!packmega18*
║ *!checkporn* ❮reply img❯
║ *!nhentai* ❮code❯
║ *!randomhentai*
║ *!nsfwblowjob*
║ *!nsfwneko*
║ *!nsfwtrap*
║ *!nsfw* ❮1 or 0❯
║
╠══✪〘 𝐕𝐎𝐙 𝐌𝐎𝐃 〙✪══
║
║ *!esquilo* ❮reply audio❯
║ *!grave* ❮reply audio❯
║ *!estourar* ❮reply audio❯
║ *!rapidoaudio* ❮reply audio❯
║ *!lentoaudio* ❮reply audio❯
║ *!bass* ❮reply audio❯
║
╠══✪〘 𝐀𝐔𝐃𝐈𝐎 〙✪══
║
║ *!gtts* ❮la❯ ❮txt❯
║ *!playlist*
║ *!lyrics*
║ *!ptlyrics*
║ *!play* ❮music name❯
║ *!playv2* ❮music name❯
║ *!tomp3* ❮caption, reply video❯
║ *!ytsearch* ❮name❯
║ *!ytmp4* ❮yt url❯
║ *!ytmp3* ❮yt url❯
║
╠══✪〘 𝐓𝐄𝐗𝐓𝐎 〙✪══
║
║ *!fakeidentity*
║ *!txtcmd*
║ *!traduz* ❮la❯ ❮txt❯
║ *!wame*
║ *!repeat* ❮txt❯
║ *!ocr* ❮caption, reply video❯
║ *!nethunter*
║ *!idioma*
║ *!frase*
║
╠══✪〘 𝐀𝐍𝐈𝐌𝐄𝐒 〙✪══
║
║ *!randomanime*
║ *!randomshota*
║ *!randomkiss*
║ *!randomcry*
║ *!randomhug*
║ *!nekoanime*
║ *!wait* ❮caption, reply video❯
║
╠══✪〘 𝐂𝐎𝐃𝐈𝐆𝐎𝐒 〙✪══
║ *!txtomorse* ❮txt❯
║ *!morsetotxt* ❮txt❯
║ *!ebinary* ❮txt❯
║ *!dbinary* ❮txt❯
╠══✪〘 𝐑𝐀𝐍𝐊𝐈𝐍𝐆𝐒 〙✪══
║
║ *!ranklindo*
║ *!rankfeio*
║ *!rankgado*
║ *!rankcomu*
║ *!ranknazi*
║ *!rankqi*
║ *!rankfofo*
║ *!rankotaku*
║ *!rankgay*
║
╠══✪〘 𝐏𝐑𝐄𝐕𝐈𝐒𝐎𝐄𝐒 〙✪══
║
║ *!cassino*
║ *!ship* ❮num1❯ ❮num2❯
║ *!corno* ❮num1❯
║ *!nazista* ❮num1❯
║ *!comunista* ❮num1❯
║ *!dado*
║ *!gay* ❮num1❯
║ *!qi* ❮num1❯
║ *!seudia* ❮num1❯
║ *!feio* ❮num1❯
║ *!bv* ❮num1❯
║ *!gado* ❮num1❯
║ *!gostoso* ❮num1❯
║ *!gostosa* ❮num1❯
║ *!randomship* ❮num1 or n/a❯
║
╠══✪〘 𝐀𝐍𝐓𝐈𝐒 〙✪══
║
║ *!antidoc* ❮1 or 0❯
║ *!antiloc* ❮1 or 0❯
║ *!antiimg* ❮1 or 0❯
║ *!antipalavra* ❮1 or 0❯
║ *!antivideo* ❮1 or 0❯
║ *!antisticker* ❮1 or 0❯
║ *!antiaudio* ❮1 or 0❯
║ *!antictt* ❮1 or 0❯
║ *!antilink* ❮1 or 0❯
║ *!antiporn* ❮1 or 0❯
║ *!antifake* ❮1 or 0❯
║ *!antilinkhard* ❮1 or 0❯
║
╠══✪〘 𝐆𝐑𝐔𝐏𝐎𝐒 〙✪══
║
║ *!fechargp*
║ *!mudardesc*
║ *!mudarnome*
║ *!abrirgp*
║ *!linkgroup*
║ *!listadmin*
║ *!listonline*
║ *!leave*
║ *!kick* ❮dial num❯
║ *!ban* ❮reply message❯
║ *!promote* ❮dial num❯
║ *!demote* ❮dial num❯
║ *!add* ❮num❯
║ *!roletrussablock* ❮1 or 0❯
║ *!welcome* ❮1 or 0❯
║ *!simih* ❮1 or 0❯
║ *!autostickerimg* ❮1 or 0❯
║ *!onmodgrupo*
║ *!offmodgrupo*
║ *!autoreply* ❮1 or 0❯
║ *!marcar*
║ *!marcar2*
║ *!marcar3*
║ *!hidemarcar* ❮txt❯
║
╠══✪〘 𝐂𝐑𝐈𝐀𝐃𝐎𝐑 〙✪══
║
║ *!blockcmd* ❮cmd less prefix❯
║ *!unblockcmd* ❮cmd less prefix❯
║ *!alerta* ❮txt❯
║ *!addpalavra* ❮txt❯
║ *!removepalavra* ❮txt❯
║ *!limparchat* ❮txt❯
║ *!ataque* ❮txt❯
║ *!divulgar* ❮txt❯
║ *!entrargp* ❮txt❯
║ *!block* ❮num❯
║ *!unblock* ❮num❯
║
╠══✪〘 𝐌𝐎𝐄𝐃𝐀 〙✪══
║
║ *!dolarhoje*
║ *!rublohoje*
║ *!ienehoje*
║ *!librahoje*
║ *!bitcoinhoje*
║ *!realhoje*
║ *!cvoin* ❮c1❯|❮c2❯
║ *!ccoin* ❮c1❯|❮c2❯|❮num❯
║
╚═〘 𝐁𝐎𝐓 〙`
}

exports.help = help


