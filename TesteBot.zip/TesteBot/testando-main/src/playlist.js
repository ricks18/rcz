const playlist = (p) => {
    return `.•♫•♬• ༻🔊 𝙿𝚕𝚊𝚢𝚕𝚒𝚜𝚝 🔊༺ •♫•♬•
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡
❁❧ *${p}m4*
M4
❁❧ *${p}paypal*
PayPal 💰
❁❧ *${p}mood*
24kGoldn - Mood (Lyrics) ft. Iann Dior
❁❧ *${p}bebelean*
LEAN - Superiority x Towy x Osquel x Beltito x Sammy x Falsetto
❁❧ *${p}yamete*
Yamete kudasai
❁❧ *${p}tuebaiano*
777-666 (Baiano Edition) - Lil Jappz (@caiojapa71)
❁❧ *${p}pneublind*
CHEIRO DE BLINDING LIGHTS | LEOD
❁❧ *${p}cunouno*
VOU COMER SEU C* NO UNO - CLIPE OFICIAL - MC Renanzin (Clipe Oficial)
❁❧ *${p}polishcow*
POLISH COW
❁❧ *${p}amgdamuie*
Amiga Da Minha Mulher - Seu Jorge
❁❧ *${p}dstartnowpneu*
CHEIRO DE DON'T START NOW OU CHEIRO DE TAMBORZINHO | LEOD
❁❧ *${p}wthisdown*
SoulChef - Write This Down (Feat. Nieve)
❁❧ *${p}goticrabuda*
Rapxis - Gótica Rabuda (Feat. Libiuz)
❁❧ *${p}yougirlistenme*
Rapxis - Sua Mina Me Escuta 🎧 (Prod. Gohann)

(𝑴𝑼𝑰𝑻𝑨𝑺 𝑴𝑼𝑺𝑰𝑪𝑨𝑺 𝑵𝑨𝑶 𝑭𝑼𝑵𝑪𝑰𝑶𝑵𝑨𝑹𝑨𝑶`
}
exports.playlist = playlist