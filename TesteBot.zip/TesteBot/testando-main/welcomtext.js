const welcome = (number, groupname) => {
    return `𝐎𝐥𝐚 @${number}. 𝐒𝐞𝐣𝐚 𝐛𝐞𝐦-𝐯𝐢𝐧𝐝𝐨 𝐚𝐨 𝐠𝐫𝐮𝐩𝐨 ${groupname}`
}
exports.welcome = welcome

const bye = (number) => {
    return `Adeus @${number}. Já vai tarde 👋`
}
exports.bye = bye