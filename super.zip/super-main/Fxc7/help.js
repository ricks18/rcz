// menu fitur bot
const help = (prefix, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `



╭──────「 *𝐑𝐄𝐆𝐔𝐋𝐀𝐂𝐀𝐎 ${name}* 」
┴
┣⊱  \`\`\`NOME DE USUÁRIO:\`\`\` *${pushname2}*
┣⊱  \`\`\`VERIFICAÇÃO:\`\`\` ✅
┣⊱  \`\`\`LIMITE:\`\`\` *${limitt} perhari*
┣⊱  \`\`\`ATIVO:\`\`\` ${kyun(uptime)}
┣⊱  \`\`\`HORA:\`\`\` *${jam} WIB*
┣⊱  \`\`\`DATA:\`\`\` *${tanggal}*
┣⊱  \`\`\`VERSÃO:\`\`\` *3.0.0*
┣⊱  \`\`\`USUÁRIO REGISTRADO:\`\`\` *${user.length} User*
┣⊱  ❌ *SPAM*
┣⊱  ❌ *CALL & VC*
┣⊱  \`\`\`DESOBEDECENDO??\`\`\` *BANIDO + SAIU DO GRUPO*
┬
╰────────────────────────


╭──────「 *𝐒𝐎𝐁𝐑𝐄 ${name}* 」
┴
│🐊 *${prefix}report bug*
│🐊 *${prefix}info*
│🐊 *${prefix}donasi*
│🐊 *${prefix}limit*
│🐊 *${prefix}owner*
│🐊 *${prefix}speed*
│🐊 *${prefix}daftar*
│🐊 *${prefix}totaluser*
│🐊 *${prefix}blocklist*
│🐊 *${prefix}banlist*
│🐊 *${prefix}premiumlist*
│🐊 *${prefix}bahasa*
┬
╰────────────────────────


͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *𝐁𝐀𝐈𝐗𝐀𝐑 𝐌𝐈𝐃𝐈𝐀* 」
┴
│🐊 *${prefix}tiktokstalk username*
│🐊 *${prefix}igstalk _farhan_xcode7*
│🐊 *${prefix}instavid link valid*
│🐊 *${prefix}instaimg link valid*
│🐊 *${prefix}instastory username*
│🐊 *${prefix}ssweb url*
│🐊 *${prefix}url2img Url*
│🐊 *${prefix}tiktok*
│🐊 *${prefix}fototiktok*
│🐊 *${prefix}memeindo*
│🐊 *${prefix}kbbi*
│🐊 *${prefix}wait*
│🐊 *${prefix}trendtwit*
│🐊 *${prefix}google últimas notícias*
┬
╰────────────────────────


╭──────「 *𝐌𝐄𝐍𝐔 𝐃𝐄 𝐂𝐑𝐈𝐀𝐃𝐎𝐑* 」
┴
│🐊 *${prefix}quotemaker tx/wtrmk/tema*
│🐊 *${prefix}nulis nama/kelas/text*
│🐊 *${prefix}croman FXC7 dan BOT*
│🐊 *${prefix}slide Fxc7 BOT WA*
│
│🐊 *${prefix}tahta FXC7*
│🐊 *${prefix}cglass FXC7*
│🐊 *${prefix}cstyle FXC7*
│🐊 *${prefix}cgame FXC7*
│🐊 *${prefix}clove FXC7*
│🐊 *${prefix}cparty FXC7*
│🐊 *${prefix}csky FXC7*
│🐊 *${prefix}gtts pt Haii*
│🐊 *${prefix}ttp Fxc7*
│🐊 *${prefix}cballon Fxc7*
│🐊 *${prefix}cpaper Fxc7*
│
│🐊 *${prefix}stiker*
│🐊 *${prefix}gifstiker*
│🐊 *${prefix}toimg*
│🐊 *${prefix}img2url*
│🐊 *${prefix}tomp3*
│🐊 *${prefix}ocr*
┬
╰──────────────────────────


╭───────「 *𝐒𝐎𝐌𝐄𝐍𝐓𝐄 𝐏𝐀𝐑𝐀 𝐆𝐑𝐔𝐏𝐎* 」
┴
│🐊 *${prefix}modeanime On/Off*
│🐊 *${prefix}naruto*
│🐊 *${prefix}minato*
│🐊 *${prefix}boruto*
│🐊 *${prefix}hinata*
│🐊 *${prefix}sakura*
│🐊 *${prefix}sasuke*
│🐊 *${prefix}toukachan*
│🐊 *${prefix}rize*
│🐊 *${prefix}akira*
│🐊 *${prefix}itori*
│🐊 *${prefix}kurumi*
│🐊 *${prefix}miku*
│🐊 *${prefix}anime*
│🐊 *${prefix}animecry*
│🐊 *${prefix}neonime*
│🐊 *${prefix}animekiss*
┬
╰───────────────────────

╭───────「 *𝐒𝐎𝐌𝐄𝐍𝐓𝐄 𝐏𝐀𝐑𝐀 𝐆𝐑𝐔𝐏𝐎* 」
┴
│🐊 *${prefix}welcome On/Off*
│🐊 *${prefix}grup buka/tutup*
│🐊 *${prefix}ownergrup*
│🐊 *${prefix}setpp*
│🐊 *${prefix}infogc*
│🐊 *${prefix}add 5521xxxxxxxxxx*
│🐊 *${prefix}kick @mentioned*
│🐊 *${prefix}kicktime @mentioned*
│🐊 *${prefix}promote @mentioned*
│🐊 *${prefix}demote @mentioned*
│🐊 *${prefix}setname*
│🐊 *${prefix}setdesc*
│🐊 *${prefix}linkgrup*
│🐊 *${prefix}tagme*
│🐊 *${prefix}hidetag*
│🐊 *${prefix}tagall*
│🐊 *${prefix}mentionall*
│🐊 *${prefix}fitnah*
│🐊 *${prefix}listadmin*
┬
╰────────────────────────

╭───────「 *𝐒𝐎𝐌𝐄𝐍𝐓𝐄 𝐏𝐀𝐑𝐀 𝐆𝐑𝐔𝐏𝐎* 」
┴
│🐊 *${prefix}nsfw On/Off*
│🐊 *${prefix}nsfwloli*
│🐊 *${prefix}nsfwblowjob*
│🐊 *${prefix}nsfwneko*
│🐊 *${prefix}nsfwtrap*
│🐊 *${prefix}hentai*
│🐊 *${prefix}simih On/Off*
┬
╰────────────────────────


╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}anjing*
│🐊 *${prefix}kucing*
│🐊 *${prefix}testime*
│🐊 *${prefix}hilih*
│🐊 *${prefix}apakah*
│🐊 *${prefix}kapankah*
│🐊 *${prefix}bisakah*
│🐊 *${prefix}rate*
│🐊 *${prefix}watak*
│🐊 *${prefix}hobby*
│🐊 *${prefix}infogempa*
│🐊 *${prefix}infonomor*
│🐊 *${prefix}quotes*
│🐊 *${prefix}truth*
│🐊 *${prefix}dare*
│🐊 *${prefix}katabijak*
│🐊 *${prefix}fakta*
│🐊 *${prefix}darkjokes*
│🐊 *${prefix}bucin*
│🐊 *${prefix}pantun*
│🐊 *${prefix}katacinta*
│🐊 *${prefix}jadwaltvnow*
│🐊 *${prefix}hekerbucin*
│🐊 *${prefix}katailham*
┬
╰────────────────────────

╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}jarak Banyuwangi/Surabaya*
│🐊 *${prefix}translate en/Apa kabar?*
│🐊 *${prefix}pasangan Farhan/Iriene*
│🐊 *${prefix}gantengcek Farhan*
│🐊 *${prefix}cantikcek Iriene*
│🐊 *${prefix}artinama Farhan*
│🐊 *${prefix}persengay Topan*
│🐊 *${prefix}pbucin Farhan*
│🐊 *${prefix}bpfont Farhan*
│🐊 *${prefix}textstyle FXC7*
│🐊 *${prefix}jadwaltv antv*
│🐊 *${prefix}lirik melukis senja*
│🐊 *${prefix}chord Melukis senja*
│🐊 *${prefix}wiki Adolf Hitler*
│🐊 *${prefix}brainly pertanyaan*
│🐊 *${prefix}resepmasakan rawon*
│🐊 *${prefix}map Banyuwangi*
│🐊 *${prefix}film Fast and Farious*
│🐊 *${prefix}pinterest gambar kucing*
│🐊 *${prefix}infocuaca Banyuwangi*
│🐊 *${prefix}jamdunia Banyuwangi*
│🐊 *${prefix}mimpi Ular*
│🐊 *${prefix}infoalamat jalan Banyuwangi*
│🐊 *${prefix}playstore WhatsApp*
┬
╰───────────────────────────


╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}puisiimg*
│🐊 *${prefix}asupan*
│🐊 *${prefix}tebakgambar*
│🐊 *${prefix}caklontong*
│🐊 *${prefix}family100*
│🐊 *${prefix}kalkulator 13*12*
│🐊 *${prefix}moddroid lightroom*
│🐊 *${prefix}happymod lightroom*
┬
╰────────────────────────

╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}cerpen*
│🐊 *${prefix}cersex*
│🐊 *${prefix}randombokep*
│🐊 *${prefix}pornhub stepMoms*
│🐊 *${prefix}xvideos japan*
│🐊 *${prefix}nekopoi oni chichi*
┬
╰────────────────────────

╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}jadwalsholat Banyuwangi*
│🐊 *${prefix}quran*
│🐊 *${prefix}quranlist*
│🐊 *${prefix}quransurah 1*
┬
╰────────────────────────

╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}becrypt string*
│🐊 *${prefix}encode64 string*
│🐊 *${prefix}decode64 encrypt*
│🐊 *${prefix}encode32 string*
│🐊 *${prefix}decode32 encrypt*
│🐊 *${prefix}encbinary string*
│🐊 *${prefix}decbinary encrypt*
│🐊 *${prefix}encoctal string*
│🐊 *${prefix}decoctal encrypt*
│🐊 *${prefix}hashidentifier Encrypt Hash*
│🐊 *${prefix}dorking dork*
│🐊 *${prefix}pastebin teks*
│🐊 *${prefix}tinyurl link*
│🐊 *${prefix}bitly link*
┬
╰────────────────────────

╭──────「 *𝐃𝐈𝐕𝐄𝐑𝐂𝐀𝐎* 」
┴
│🐊 *${prefix}spamcall 083xxxxxxxxx*
│🐊 *${prefix}spamsms 083xxxxxxxx/jumlah*
│🐊 *${prefix}spamgmail contoh@gmail.com*
┬
╰────────────────────────


╭─────────「 *𝐒𝐎𝐌𝐄𝐍𝐓𝐄 𝐏𝐀𝐑𝐀 𝐎 𝐃𝐎𝐍𝐎* 」
┴
│🐊 *${prefix}addprem mentioned*
│🐊 *${prefix}removeprem mention*
│🐊 *${prefix}setmemlimit*
│🐊 *${prefix}setreply*
│🐊 *${prefix}setprefix*
│🐊 *${prefix}setnamebot*
│🐊 *${prefix}setppbot*
│🐊 *${prefix}bc*
│🐊 *${prefix}bcgc*
│🐊 *${prefix}ban*
│🐊 *${prefix}unban*
│🐊 *${prefix}block*
│🐊 *${prefix}unblock*
│🐊 *${prefix}clearall*
│🐊 *${prefix}delete*
│🐊 *${prefix}clone*
│🐊 *${prefix}getses*
│🐊 *${prefix}leave*
┬
╰────────────────────────


╭────────「 *𝐔𝐒𝐔𝐀𝐑𝐈𝐎𝐒 𝐏𝐑𝐄𝐌𝐈𝐔𝐌* 」
┴
⚜️ *${prefix}playmp3 nome*
⚜️ *${prefix}fb link video*
⚜️ *${prefix}snack link snack video*
⚜️ *${prefix}ytmp3 link yt*
⚜️ *${prefix}ytmp4 link yt*
⚜️ *${prefix}joox Monólogo Final*
⚜️ *${prefix}smule Link Video Smule*
┬
╰────────────────────────


╭─────「 *𝐋𝐄𝐕𝐄𝐋 ${name}* 」
┴
│🔧 
│🔧 
│🔧 
┬
╰────────────────────────`
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// donasi menu
const donasi = (name) => { 
	return `       
╭─────「 *𝐃𝐎𝐀𝐑* 」
┴
│√ *nao*
┬
╰──────「 *POR ${name}* 」

'
`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
Lista de idiomas para comando *${prefix}gtts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitend = (pushname2) => {
        return`*Desculpe ${pushname2} O limite de hoje acabou*\n*O limite é redefinido a cada meia-noite*`
}

const limitcount = (limitCounts) => {
        return`
Seu limite: ${limitCounts}
`
}

exports.limitend = limitend
exports.limitcount = limitcount
