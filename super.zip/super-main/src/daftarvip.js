const daftarvip = (prefix) => { 
	return `
	
*𝐏𝐑𝐄𝐂̧𝐎𝐒 𝐃𝐀 𝐋𝐈𝐒𝐓𝐀 𝐕𝐈𝐏 :*

-R$. 10 > Acessar recursos ViP
-R$. 20 > Recursos VIP + Insira o bot no seu grupo!

*𝐒𝐄 𝐐𝐔𝐄𝐑 𝐑𝐄𝐆𝐈𝐒𝐓𝐀𝐑 𝐕𝐈𝐏 :*

*Proprietário do bate-papo BOT :*

wa.me/5511974980928 ou digite *${prefix}owner*
`
}
exports.daftarvip = daftarvip