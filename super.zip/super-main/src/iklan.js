const iklan = () => { 
	return `           
𝐍𝐀𝐎
`
}
exports.iklan = iklan