const nekopoi = () => { 
	return `       
Acesso ruim / assistindo Nekopoi sem baixar VPN? Clique no link abaixo, role para baixo e digite concordar e conectar.

https://www.hidemyass-freeproxy.com/proxy/id-id/aHR0cHM6Ly9uZWtvcG9pLmNhcmUv

*Selamat Menonton*`
}
exports.nekopoi = nekopoi