const help = (prefix) => {
	return `
╔══✪〘 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂𝐎𝐄𝐒〙✪══
║
╠ *🤖𝑺𝑯𝑼𝑹𝑬𝑲 𝑩𝑶𝑻🤖* 
╠🤖 VERSÃO: *3.0*
╠🤖 𝐃𝐎𝐍𝐎: 𝗵𝗲𝗻𝗿𝗶𝗾𝘂𝗲 
╠🤖 *wa.me/+14314003552*
╠🤖 𝐒𝐓𝐀𝐓𝐔𝐒: ON
╠🤖 Digite *.info*
║
╠══✪〘 𝐍𝐎𝐕𝐎𝐒 〙✪══
║
║📌 *.animecry*
║⚜️ *.chentai [premium]*
║⚜️ *.gcpf [premium]*
║📌 *.gay [@]*
║⚜️ *.packs [premium]*
║⚜️ *.destrava [premium]*
║⚜️ *.gpessoa [premium]*
║📌 *.wame*
║📌 *.spamcall*
║📌 *.vini*
║📌 *.bug*
║📌 *.link* (para divulgar seu número)
║
╠══✪〘 𝐌𝐄𝐍𝐔 〙✪══
║
║📌 *.figu*
║📌 *.toimg*
║📌 *.darkjokes (memes aleatórios)*
║📌 *.memeindo*
║📌 *.lolih [on]*
║📌 *.nsfwloli [off]*
║📌 *.url2img*
║📌 *.leens [na legenda]*
║📌 *.wait [na legenda]*
║📌 *.setprefix*
║
╠══✪〘 𝐎𝐔𝐓𝐑𝐎𝐒 〙✪══
║
║📌 *.bc [texto]* (ele faz uma ™)
║📌 *.bloqueados*
║📌 *.bloquear [@]*
║📌 *.desbloquear [@]*
║📌 *.limpar*
║📌 *.bc [ *texto* ]*
║📌 *.help1*
║📌 *.dono1*
║📌 *.setnome*
║📌 *.termux*
║📌 *.setfoto*
║📌 *.ytmp4*
║📌 *.bomdia*
║📌 *.boanoite*
║
╠══✪〘 𝐈𝐌𝐀𝐆𝐄𝐍𝐒 〙✪══
║
║📷 *.loli* [off]
║📷 *.loli1*
║📷 *.hentai*
║📷 *.dono1*
║📷 *.porno*
║📷 *.boanoite*
║📷 *.bomdia*
║📷 *.boatarde*
║📷 *.mia [aleatórias]*
║📷 *.rize [aleatórias]*
║📷 *.minato [aleatórias]*
║📷 *.boruto [aleatórias]*
║📷 *.hinata [aleatórias]*
║📷 *.sasuke [aleatórias]*
║📷 *.sakura [aleatórias]*
║📷 *.naruto [aleatórias]*
║📷 *.meme*   
║📷 *.lofi*
║📷 *.malkova*
║📷 *.canal*
║📷 *.nsfwloli1*
║📷 *.reislin*
║
╠══✪〘 𝗜𝗡𝗧𝗘𝗟𝗜𝗚𝗘𝗡𝗖𝗜𝗔 〙✪══
║
║🧠 *.simih 1 (para ativar)*
║🧠 *.simih 0 (para desativar)*
║ *.simi (sua mensagem)*
║
╠══✪〘 𝐄𝐌 𝐏𝐑𝐎𝐃𝐔𝐂𝐀𝐎 〙✪══
║
║🔧 *.*
║🔧 *.*
║🔧 *.*
║
╠══✪〘 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 〙✪══
║
║⚜️ *.dado*
║⚜️ *.cekvip*
║⚜️ *.premiumlist*
║⚜️ *.delete*
║⚜️ *.modapk*
║⚜️ *.indo10*
║⚜️ *.daftarvip [para virar Premium]*
║⚜️ *.qrcode*
║⚜️ *.chentai*
║⚜️ *.gcpf*
║⚜️ *.packs*
║⚜️ *.destrava*
║⚜️ *.gpessoa*
║
╠══✪〘 𝐆𝐑𝐔𝐏𝐎 〙✪══
║
║🌌 *.banir* [@ da pessoa]
║🌌 *.leveling [on/off]*
║🌌 *.level*
║🌌 *.add* [número]
║🌌 *.promover* [@ da pessoa]
║🌌 *.setfoto [na legenda]*
║🌌 *.setname [texto]*
║🌌 *.rebaixar* [@ da pessoa]
║🌌 *.admins*
║🌌 *.marcar*
║🌌 *.marcar2*
║🌌 *.marcar3*
║🌌 *.bemvindo [1/0]*
║🌌 *.grupoinfo*
║🌌 *.bomdia*
║🌌 *.boatarde*
║🌌 *.boanoite*
║🌌 *.setdesc*
║🌌 *.bug [sua mensagem]*
║🌌 *.linkgp*
║
╠══✪〘 𝐄𝐒𝐏𝐄𝐂𝐈𝐅𝐈𝐂𝐎 𝐃𝐎 𝐁𝐎𝐓 〙✪══
║
║🤖 *.bug [sua mensagem]*
║🤖 *.dono1*
║🤖 *.ping [ver velocidade do bot]*
║🤖 *.termux*
║🤖 *.gay [@]*
║🤖 *.wame*
║🤖 *.map (nome)*
║🤖 *.setppbot (marque uma img)*
║🤖 *.pinterest (nome)*
║🤖 *.desligar (so para o dono)*
║🤖 *.timer*
║
╠══✪〘 𝐌𝐀𝐈𝐒 𝐀𝐋𝐆𝐔𝐍𝐒 〙✪══
║
║📌 *.neko*
║📌 *.ttp [texto]*
║📌 *.testime*
║📌 *.tomp3*
║📌 *.modoanime [on/off]*
║📌 *.modonsfw [on/off]*
║📌 *.happymod [jogo/app]*
║📌 *.rize*
║📌 *.ytsearch*
║📌 *.moddroid [jogo/app]*
║📌 *.xvideos [titulo]**
║📌 *.nomegp*
║📌 *.darkjokes (memes aleatórios)*
║📌 *.animecry*
║📌 *.gay1*
║📌 *.next*
║📌 *.alerta*
║📌 *.belle [img aleatórias]*
║📌 *.pronomeneu [texto]*
║📌 *.hobby*
║
╠══✪〘 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐃𝐄 𝐕𝐎𝐙 〙✪══
║📌 *.gtts (idioma) (texto)* ex: *.gtts pt Olá*
╠══✪〘 𝐎𝐔𝐓𝐑𝐎𝐒 /𝟐 〙✪══
║
║📌 *.antilink [1/0]*
║📌 *.brainly [pergunta]*
║📌 *.antiracismo [on/off]*
║📌 *.setnomebot*
║📌 *.meme*
║
╠════════════════════
╠══✪〘 𝐒𝐇𝐔𝐑𝐄𝐊 𝐁𝐎𝐓 〙✪══
║
║   *⚠️Se alguns comandos
║       não funcionarem, não insista ⚠️*
║
╚═〘 𝐁𝐎𝐓 〙`
}

exports.help = help

