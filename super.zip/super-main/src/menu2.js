const menu2 = (prefix) => { 
	return `                 
╠══✪〘 𝐌𝐄𝐍𝐔 〙✪══
║
╠🐊 *${prefix}figu*
╠🐊 *${prefix}toimg*
╠🐊 *${prefix}meme*
╠🐊 *${prefix}memeindo*
╠🐊 *${prefix}tts*
╠🐊 *${prefix}loli [off]*
╠🐊 *${prefix}nsfwloli [off]*
╠🐊 *${prefix}url2img*
╠🐊 *${prefix}leens [na legenda]*
╠🐊 *${prefix}wait [na legenda]*
╠🐊 *${prefix}setprefix*
║🐊 *${prefix}pub*
║🐊 *${prefix}gglogo*
║
╠══✪〘 𝐈𝐌𝐀𝐆𝐄𝐍𝐒 〙✪══
║
╠📷 *${prefix}loli* [off]
╠📷 *${prefix}loli1*
╠📷 *${prefix}hentai*
╠📷 *${prefix}dono*
╠📷 *${prefix}porno*
╠📷 *${prefix}boanoite*
╠📷 *${prefix}bomdia*
╠📷 *${prefix}boatarde*
╠📷 *${prefix}mia*
╠📷 *${prefix}mia1*
╠📷 *${prefix}mia2*
╠📷 *${prefix}belle*
╠📷 *${prefix}belle1*
╠📷 *${prefix}belle2*
╠📷 *${prefix}belle3*
╠📷 *${prefix}akeno*
╠📷 *${prefix}meme*   
╠📷 *${prefix}lofi*
╠📷 *${prefix}malkova*
╠📷 *${prefix}canal*
╠📷 *${prefix}nsfwloli1*
╠📷 *${prefix}reislin*
║
╠══✪〘 𝗜𝗡𝗧𝗘𝗟𝗜𝗚𝗘𝗡𝗖𝗜𝗔 𝗜𝗔 〙✪══
║
╠🤖 *${prefix}simih 1 (para ativar)*
╠🤖 *${prefix}simih 0 (para desativar)*
╠🤖 *${prefix}simi (sua mensagem)*
║
╠══✪〘 *𝐇* 〙✪══`
}
exports.menu2 = menu2