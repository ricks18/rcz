const vipmenu = (prefix) => { 
	return `            
	
╔══✪〘 𝐔𝐒𝐔𝐀𝐑𝐈𝐎 𝐕𝐈𝐏⚜️ 〙✪══
║
╠⚜️ *${prefix}dado*
╠⚜️ *${prefix}cekvip*
╠⚜️ *${prefix}premiumlist*
╠⚜️ *${prefix}delete*
╠⚜️ *${prefix}modapk*
╠⚜️ *${prefix}indo10*
╠⚜️ *${prefix}daftarvip [para virar Premium]*
╠⚜️ *${prefix}qrcode*
╠⚜️ *${prefix}chentai*
╠⚜️ *${prefix}gcpf*
╠⚜️ *${prefix}packs*
╠⚜️ *${prefix}destrava*
╠⚜️ *${prefix}gpessoa*
║
║
╚══✪〘  𝐒𝐇𝐔𝐑𝐄𝐊 𝐁𝐎𝐓 〙✪══
`
}
exports.vipmenu = vipmenu