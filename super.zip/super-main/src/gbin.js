const gbin = () => { 
	return `       
	*PACKS:*
    
	*𝓥𝓘𝓒𝓣𝓞𝓡 𝓝𝓞 𝓒𝓞𝓜𝓐𝓝𝓓𝓞 ⚜️🐊*
	
	Belle delphine : https://photos.app.goo.gl/Jr4Qk1dFSJepPdRc7 
	
	Pack1: https://photos.app.goo.gl/phyRpNFLcAtsknfJ7 
	
	Kitty kum: https://photos.app.goo.gl/gNxLbJHGVzeWY9iS9 
	
	Misaki Your Waifu: https://photos.app.goo.gl/M9nyHdonAJu5GRjZ9 
	
	pack: https://photos.app.goo.gl/SrogbCbnanL2PJQn7 
	
	Love Lilah: https://photos.app.goo.gl/TBbkjGGdAVHjPFt5A
	
	Bunnicult: https://mega.nz/folder/OEs0ECjT#IebZ-NJHPHlY2RBu7nzNXg
	
	Stormi Maya [1TB]:  https://mega.nz/folder/esYjUIbK#XJQoY57ufIwD-ZicjzVbvg/folder/nw4VXawZ

    Fegalvao: https://mega.nz/folder/PxMnACwK#DcVldG6RuwT3zAScX2aZ8A

    Mis4to brownie: https://mega.nz/folder/zxwBkKLJ#leusMgiBSe6Qbh5bIILwzg/folder/n1hGkZYb

    Dre@m 4791: https://mega.nz/folder/N9RnQYgC#3yKMaH7UkVE6dMLfVJ2NGw

    Hana_c4: https://mega.nz/folder/zR8g0LIa#MnPOOw5BXpY431_-casKMw

    The Emily lynne 44gb: https://mega.nz/folder/hNginAjB#GesqqUAbjiPtJUdQAgnmlQ

    Jewelz blu 25gb: https://mega.nz/folder/DRgnhLZb#61s53bmqoCJjYrpOYJqarA

    Emmabanks808: https://mega.nz/folder/ABtFxKoT#ViT37OhGH5Y95ZpMn-0r9w

    Wildtequilla 18gb: https://mega.nz/folder/TlgjSQyQ#lb_39aGFK0cH_nTYHtcEow

    Badbabyrubez: https://mega.nz/folder/KIkQQYiK#htdAX2J4LkcR-hthsZTvvQ

    Kitty kum 19gb: https://mega.nz/folder/iA8kWIjD#0NbW6c7ra8RXaCZeG15nuQ

    Violet m: https://mega.nz/folder/orwj3YiB#T71p81GK2nGfe0yAxtJjrA

    Zoe aka canbebought: https://mega.nz/folder/E9ZinLiQ#MMkkPVNJ_Vw-zBKBoTx81g

    Vanessa vailatti: https://mega.nz/folder/vQdGiCYB#_YwxVURtYjN72wo3gar1Ew`
}
exports.gbin = gbin